import { useEffect, useState } from 'react';
import axios from 'axios';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import CloseOutlinedIcon from '@mui/icons-material/CloseOutlined';
import Grid from '@mui/material/Grid';
import IconButton from '@mui/material/IconButton';
import useInterval from './Helpers/useInterval';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import OutlinedInput from '@mui/material/OutlinedInput';
import AccessAlarmIcon from '@mui/icons-material/AccessAlarm';
import Draggable from 'react-draggable';


export default function NewsFeed({ widgets, setWidgets, id }) {

    const baseUrl = "http://localhost:5001";
    console.log(widgets)
    const index = widgets.findIndex((w) => w.id === id);
    const widget = widgets[index];
    const deepCopy = JSON.parse(JSON.stringify(widgets));

    const [articles, setArticles] = useState(null);
    const [timer, setTimer] = useState(widget.timer ?? 0);
    const [open, setOpen] = useState(false);

    useInterval(() => {
        if (timer != 0) {
            loadNews();
        }
    }, timer);



    useEffect(() => {
        loadNews();
    }, [])

    const loadNews = () => {
        const options = {
            method: 'GET',
            url: `${baseUrl}/news`,
        }

        axios.request(options)
            .then((response) => {
                setArticles(response.data)

            }).catch((error) => {
                console.error(error)
            })
    }


    const handleChangeTimer = (event) => {
        setTimer(event.target.value === "" ? 0 : Number(event.target.value));
        widget.timer = event.target.value === "" ? 0 : Number(event.target.value);
        deepCopy[index] = widget;
        setWidgets(deepCopy);
    }

    const handleCloseTimer = (event, reason) => {
        if (reason !== 'backdropClick') {
            setOpen(false);
        }
    }

    const handleCloseWidget = () => {
        const updatedWidgets = widgets.filter((w) => w.id !== id);
        console.log(updatedWidgets);
        setWidgets(updatedWidgets);
    }


    return (

        <Draggable>
            <Box sx={{ width: 350, mx: 3, my: 3 }} >
                <Card variant="outlined">
                    <Grid container justifyContent="space-between" alignItems="center" sx={{ bgcolor: 'primary.dark' }}>
                        <Grid item xs={10}>
                            <Typography sx={{ mx: 1, px: 1 }} variant="h6" color="white">News Feed</Typography>
                        </Grid>
                        <Grid item xs={1}>
                            <IconButton onClick={() => setOpen(true)}>
                                <AccessAlarmIcon />
                            </IconButton>
                            <Dialog disableEscapeKeyDown open={open} >
                                <DialogTitle sx={{ ml: 1 }}>Set Timer</DialogTitle>
                                <DialogContent>
                                    <Box component="form" sx={{ display: 'flex', flexWrap: 'wrap' }}>
                                        <FormControl sx={{ m: 1, minWidth: 60 }}>
                                            <InputLabel htmlFor="demo-dialog-native">Timer</InputLabel>
                                            <Select
                                                native
                                                value={timer}
                                                onChange={handleChangeTimer}
                                                input={<OutlinedInput label="Timer" id="demo-dialog-native" />}
                                            >
                                                <option aria-label="None" value="" />
                                                <option value={0}>Pas de timer</option>
                                                <option value={10000}>10 sec</option>
                                                <option value={600000}>30 min</option>
                                                <option value={3600000}>1 h</option>
                                            </Select>
                                        </FormControl>
                                    </Box>
                                </DialogContent>
                                <DialogActions>
                                    <Button onClick={handleCloseTimer} >OK</Button>
                                </DialogActions>
                            </Dialog>
                        </Grid>
                        <Grid item xs={1}>
                            <IconButton onClick={handleCloseWidget}>
                                <CloseOutlinedIcon />
                            </IconButton>
                        </Grid>
                    </Grid>
                    {articles ? (
                        <CardContent sx={{ bgcolor: 'primary.light' }}>
                            {articles.map((article, _index) => (
                                <div key={_index}>
                                    <a href={article.url} target="_blank" rel="noreferrer">
                                        <Typography sx={{ mb: 1.5, px: 1, fontSize: 14 }} variant="h6" color="white">
                                            {article.title}
                                        </Typography></a>
                                </div>))}
                        </CardContent>
                    ) : (
                        <div>
                            Loading
                        </div>
                    )}
                </Card>
            </Box>
        </Draggable>
    )
}