import axios from 'axios';

export const weatherController = async (req, res) => {
  try {
    const API_KEY =
      process.env.OPEN_API_KEY || `54503b82e07d1d61e4e98a9dd5e8a04e`;
    const { city } = req.body;
    console.log('city', city);
    const url = `http://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`;
    const { data } = await axios.get(url);
    res.status(200).json({
      data,
    });
  } catch (error) {
    res.send(error);
  }
};
