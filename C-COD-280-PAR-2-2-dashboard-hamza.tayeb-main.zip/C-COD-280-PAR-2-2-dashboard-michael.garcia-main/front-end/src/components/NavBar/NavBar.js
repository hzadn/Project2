import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import { useNavigate } from 'react-router';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import InputLabel from '@mui/material/InputLabel';
import OutlinedInput from '@mui/material/OutlinedInput';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';

export default function ButtonAppBar(props) {
    const { isLoggedIn, setIsLoggedIn, widgets, setWidgets } = props
    const [open, setOpen] = React.useState(false);
    const [newWidgetName, setNewWidgetName] = React.useState("");
    const [btnDisabled, setBtnDisabled] = React.useState(true);

    const user = localStorage.user ? JSON.parse(localStorage.user) : {};

    const isAdmin = user.is_admin;

    const navigate = useNavigate();

    const logout = () => {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        setIsLoggedIn(false);
        navigate('/signin')
    };
    const login = () => {
        navigate('/signin')
    }

    const addWidget = () => {
        setOpen(false);
        const d = new Date();
        const newId = d.getTime();
        const newWidget = {};
        newWidget.id = newId;
        newWidget.name = newWidgetName;
        const deepCopy = JSON.parse(JSON.stringify(widgets));
        deepCopy.push(JSON.parse(JSON.stringify(newWidget)));
        setWidgets(deepCopy);
        setNewWidgetName("");
        setBtnDisabled(true);
    }

    const handleChange = (event) => {
        setNewWidgetName(event.target.value || '');
        setBtnDisabled(!event.target.value);
    };

    const handleClose = (event, reason) => {
        if (reason !== 'backdropClick') {
            setNewWidgetName("");
            setOpen(false);
            setBtnDisabled(true);
        }
    }

    return (
        <Box sx={{ flexGrow: 1 }}>
            <AppBar position="static">
                <Toolbar>
                    <IconButton
                        size="large"
                        edge="start"
                        color="inherit"
                        aria-label="menu"
                        sx={{ mr: 2 }}
                    >
                        <MenuIcon />
                    </IconButton>
                    <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                        Dashboard
                    </Typography>
                    {isLoggedIn ? (
                        <div>
                            <Button color="secondary" variant="contained" onClick={logout}>Logout</Button>
                            <Button color="primary" variant="contained" sx={{ mr: 3.5 }} onClick={() => setOpen(true)}>
                                Add Widget
                            </Button>
                            <Dialog disableEscapeKeyDown open={open} onClose={handleClose}>
                                <DialogTitle sx={{ ml: 3 }}>Select new Widget</DialogTitle>
                                <DialogContent>
                                    <Box component="form" sx={{ display: 'flex', flexWrap: 'wrap' }}>
                                        <FormControl sx={{ m: 1, minWidth: 120 }}>
                                            <InputLabel htmlFor="demo-dialog-native">Widget</InputLabel>
                                            <Select
                                                native
                                                value={newWidgetName}
                                                onChange={handleChange}
                                                input={<OutlinedInput label="Widget" id="demo-dialog-native" />}
                                            >
                                                <option aria-label="None" value="" />
                                                <option value={"Weather"}>Weather</option>
                                                <option value={"Weather2"}>Min Max Temp</option>
                                                <option value={"Weather3"}>Wind</option>
                                                <option value={"CategoryBlagues"}>CategoryBlagues</option>
                                                <option value={"RandomBlagues"}>RandomBlagues</option>
                                                <option value={"CurrencyConverter"}>CurrencyConverter</option>
                                                <option value={"NewsFeed"}>NewsFeed</option>
                                                <option value={"Pokemon"}>Pokedex</option>
                                                {isAdmin &&
                                                    < option value={"CrudUsers"}>CrudUsers</option>
                                                }
                                                {!isAdmin &&
                                                    < option value={"Users"}>Users</option>
                                                }
                                            </Select>
                                        </FormControl>
                                    </Box>
                                </DialogContent>
                                <DialogActions>
                                    <Button onClick={handleClose}>Cancel</Button>
                                    <Button onClick={addWidget} disabled={btnDisabled}>Add</Button>
                                </DialogActions>
                            </Dialog>
                        </div>
                    ) : (
                        <Button onClick={login} color="inherit" variant="outlined">Sign-in</Button>
                    )}
                </Toolbar>
            </AppBar>
        </Box >

    );
}
