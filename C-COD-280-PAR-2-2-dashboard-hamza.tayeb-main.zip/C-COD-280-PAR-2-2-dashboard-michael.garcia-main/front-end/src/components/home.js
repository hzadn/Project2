import React from 'react';
import Weather from './Weather';
import Weather2 from './Weather2';
import Weather3 from './Weather3';
import NewsFeed from "./NewsFeed";
import CurrencyConverter from "./CurrencyConverter";
import CategoryBlagues from './Blagues/CategoryBlagues';
import RandomBlagues from './Blagues/RandomBlagues';
import Pokemon from './Pokemon';
import CrudUsers from './Users/CrudUsers';
import Users from './Users/Users';

export default function Home({ widgets, setWidgets }) {

    function returnComponent(id, widgetName) {
        switch (widgetName) {
            case "Weather":
                return (
                    <Weather key={id} id={id} widgets={widgets} setWidgets={setWidgets} />
                )
            case "Weather2":
                return (
                    <Weather2 key={id} id={id} widgets={widgets} setWidgets={setWidgets} />
                )
            case "Weather3":
                return (
                    <Weather3 key={id} id={id} widgets={widgets} setWidgets={setWidgets} />
                )
            case "RandomBlagues":
                return (
                    <RandomBlagues key={id} id={id} widgets={widgets} setWidgets={setWidgets} />
                )
            case "CategoryBlagues":
                return (
                    <CategoryBlagues key={id} id={id} widgets={widgets} setWidgets={setWidgets} />
                )
            case "CurrencyConverter":
                return (
                    <CurrencyConverter key={id} id={id} widgets={widgets} setWidgets={setWidgets} />
                )
            case "NewsFeed":
                return (
                    <NewsFeed key={id} id={id} widgets={widgets} setWidgets={setWidgets} />
                )
            case "Pokemon":
                return (
                    <Pokemon key={id} id={id} widgets={widgets} setWidgets={setWidgets} />
                )
            case "CrudUsers":
                return (
                    <CrudUsers key={id} id={id} widgets={widgets} setWidgets={setWidgets} />
                )
            case "Users":
                return (
                    <Users key={id} id={id} widgets={widgets} setWidgets={setWidgets} />
                )
            default:
                return (
                    <p> erreur widgetName</p>
                )
        }
    }


    return (
        <>

            <div>
                {widgets.map((widget) => (
                    returnComponent(widget.id, widget.name)
                ))}
            </div>

        </>
    );
}