import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import blaguesRoutes from './routes/blaguesRoutes.js';

dotenv.config();
const app = express();
app.use(express.json());
app.use(cors());

const port = process.env.PORT || 3010;

app.get('/', (req, res) => {
    res.set('Content-Type', 'text/html');
    res.send('Welcome on blagues API!!');
});

app.use('/api/blagues', blaguesRoutes);

// Handle errors.
app.use(function (err, req, res, next) {
    res.status(err.status || 500);
    res.json({ error: err });
});

app.listen(port, () => {
    console.log('Server app listening on port ' + port);
});