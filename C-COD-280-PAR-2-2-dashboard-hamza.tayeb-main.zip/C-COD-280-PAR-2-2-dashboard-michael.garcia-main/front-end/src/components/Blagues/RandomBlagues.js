import axios from 'axios';
import { useState } from 'react';
import * as React from 'react';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import CloseOutlinedIcon from '@mui/icons-material/CloseOutlined';
import Grid from '@mui/material/Grid';
import IconButton from '@mui/material/IconButton';
import useInterval from '../Helpers/useInterval';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import OutlinedInput from '@mui/material/OutlinedInput';
import AccessAlarmIcon from '@mui/icons-material/AccessAlarm';
import Draggable from 'react';



export default function RandomBlagues({ widgets, setWidgets, id }) {

    const index = widgets.findIndex((w) => w.id === id);
    const widget = widgets[index];
    const deepCopy = JSON.parse(JSON.stringify(widgets));

    const [timer, setTimer] = useState(widget.timer ?? 0);
    const [open, setOpen] = useState(false);
    const [joke, setJoke] = useState('');
    const [answer, setAnswer] = useState('');
    const [showAnswer, setShowAnswer] = useState(false);

    useInterval(() => {
        if (timer != 0) {
            loadJoke();
        }
    }, timer);

    const loadJoke = async () => {

        setShowAnswer(false);

        try {
            const res = await axios.get(`http://localhost:3010/api/blagues/`);
            setJoke(res.data.blague.joke);
            setAnswer(res.data.blague.answer);
        } catch (error) {
            console.log(error);
        }

    }

    const handleChangeTimer = (event) => {
        setTimer(event.target.value === "" ? 0 : Number(event.target.value));
        widget.timer = event.target.value === "" ? 0 : Number(event.target.value);
        deepCopy[index] = widget;
        setWidgets(deepCopy);
    }

    const handleCloseTimer = (event, reason) => {
        if (reason !== 'backdropClick') {
            setOpen(false);
        }
    }

    const handleCloseWidget = () => {
        const updatedWidgets = widgets.filter((w) => w.id !== id);
        console.log(updatedWidgets);
        setWidgets(updatedWidgets);
    }
let Draggable = require('react-draggable');
    return (
<Draggable>
        <Box sx={{ width: 300, mx: 3, my: 3 }} >
            <Card variant="outlined">
                <Grid container justifyContent="space-between" alignItems="center" sx={{ bgcolor: 'primary.dark' }}>
                    <Grid item xs={10}>
                        <Typography sx={{ mx: 1, px: 1 }} variant="h6" color="white">Blagues Widget</Typography>
                    </Grid>
                    <Grid item xs={1}>
                        <IconButton onClick={() => setOpen(true)}>
                            <AccessAlarmIcon />
                        </IconButton>
                        <Dialog disableEscapeKeyDown open={open} >
                            <DialogTitle sx={{ ml: 1 }}>Set Timer</DialogTitle>
                            <DialogContent>
                                <Box component="form" sx={{ display: 'flex', flexWrap: 'wrap' }}>
                                    <FormControl sx={{ m: 1, minWidth: 60 }}>
                                        <InputLabel htmlFor="demo-dialog-native">Timer</InputLabel>
                                        <Select
                                            native
                                            value={timer}
                                            onChange={handleChangeTimer}
                                            input={<OutlinedInput label="Timer" id="demo-dialog-native" />}
                                        >
                                            <option aria-label="None" value="" />
                                            <option value={0}>Pas de timer</option>
                                            <option value={10000}>10 sec</option>
                                            <option value={30000}>30 sec</option>
                                            <option value={60000}>1 min</option>
                                        </Select>
                                    </FormControl>
                                </Box>
                            </DialogContent>
                            <DialogActions>
                                <Button onClick={handleCloseTimer} >OK</Button>
                            </DialogActions>
                        </Dialog>
                    </Grid>
                    <Grid item xs={1}>
                        <IconButton onClick={handleCloseWidget}>
                            <CloseOutlinedIcon />
                        </IconButton>
                    </Grid>
                </Grid>
                {joke ? (
                    <CardContent sx={{ bgcolor: 'primary.light' }} >
                        <Typography sx={{ mb: 1.5, px: 1, fontSize: 14, fontWeight: "bold" }} variant="h6" color="white">
                            {joke}
                        </Typography>
                        <Typography sx={{ mb: 1.5, bgcolor: 'primary.dark', px: 1, py: 1, fontSize: 14, fontWeight: "bold" }} color="white" onClick={() => setShowAnswer(true)}>
                            {showAnswer ? answer : "Montrer la réponse"}
                        </Typography>
                    </CardContent>
                ) : (
                    <CardContent sx={{ bgcolor: 'primary.light' }}>
                        <Typography sx={{ px: 1, fontSize: 14, fontWeight: "bold" }} variant="h6" color="white">
                            Random mode
                        </Typography>
                    </CardContent>
                )}
                <CardActions>
                    <Button size="medium" color="primary" variant="contained" onClick={loadJoke}>
                        {joke ? "NEXT !" : "Fais moi rigoler"}
                    </Button>
                </CardActions>
            </Card>
        </Box>
</Draggable>
    );
}