import express from 'express';
import { randomController } from '../controllers/randomController.js';
import { categoryController } from '../controllers/categoryController.js';

const router = express.Router();

router.get('/', randomController);

router.post('/category', categoryController);

export default router;