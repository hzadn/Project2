import axios from 'axios';
import { useState, useEffect } from 'react';
import * as React from 'react';
import Grid from '@material-ui/core/Grid'
import MaterialTable from "@material-table/core";
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import { forwardRef } from 'react';
import Draggable from 'react-draggable';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import CloseOutlinedIcon from '@mui/icons-material/CloseOutlined';
import IconButton from '@mui/material/IconButton';

const tableIcons = {
    Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
    Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
    Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
    DetailPanel: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
    Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
    Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
    FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
    LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
    NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
    PreviousPage: forwardRef((props, ref) => <ChevronLeft {...props} ref={ref} />),
    ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
    Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
    SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
    ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
    ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />)
};


export default function Users({ widgets, setWidgets, id }) {


    const columns = [
        { title: "id", field: "_id", hidden: true },
        { title: "Username", field: "username" },
        { title: "Email", field: "email" }
    ];
    const [data, setData] = useState([]);
    const [iserror, setIserror] = useState(false);
    const [errorMessages, setErrorMessages] = useState([]);

    useEffect(() => {

        const options = {
            method: 'GET',
            url: 'http://localhost:3001/users',
        };

        axios(options)
            .then(res => {
                console.log(res.data)
                setData(res.data)
            })
            .catch(error => {
                console.log(error)
                setErrorMessages(["Cannot load user data"])
                setIserror(true)
            })
    }, [])



    const handleCloseWidget = () => {
        const updatedWidgets = widgets.filter((w) => w.id !== id);
        console.log(updatedWidgets);
        setWidgets(updatedWidgets);
    }

    return (
        <Draggable>
            <Box sx={{ width: 500, mx: 3, my: 3 }}>
                <Grid container justifyContent="space-between" alignItems="center" sx={{ bgcolor: 'primary.dark' }} >
                    <Grid item xs={11}>
                        <Typography sx={{ width: 800, mx: 1, px: 1 }} variant="h5" color="black">USERS</Typography>
                    </Grid>
                    <Grid item xs={1}>
                        <IconButton onClick={handleCloseWidget}>
                            <CloseOutlinedIcon />
                        </IconButton>
                    </Grid>
                </Grid>
                <MaterialTable
                    style={{ width: 500 }}
                    title="User list"
                    columns={columns}
                    data={data}
                    icons={tableIcons}
                />
            </Box>

        </Draggable>
    )
}