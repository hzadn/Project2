import axios from 'axios';

export const pokemonController = async (req, res) => {
  try {
    const pokemon = req.body.pokemon;
    const url = `https://pokeapi.co/api/v2/pokemon/${pokemon}`;
    const { data } = await axios.get(url);
    console.log(pokemon)
    // console.log({ data })
    res.status(200).json({
      data,
    });
  } catch (error) {
    res.send(error);
  }
};
