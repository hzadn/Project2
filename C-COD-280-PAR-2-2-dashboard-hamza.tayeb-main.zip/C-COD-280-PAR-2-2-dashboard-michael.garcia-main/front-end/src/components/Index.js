import SignIn from "./Auth/SignIn";
import SignUp from "./Auth/SignUp";
import Home from "./home";
import {
    BrowserRouter,
    Routes,
    Route,
} from "react-router-dom";
import MenuAppBar from "./NavBar/NavBar";
import { useState, useEffect } from 'react';



export default function Index(props) {
    const { isLoggedIn, setIsLoggedIn } = props;
    const [widgets, setWidgets] = useState([]);

    useEffect(() => {
        if (localStorage.widgets) {
            setWidgets(JSON.parse(localStorage.widgets));
        }
    },
        []
    )

    useEffect(() => {
        localStorage.setItem("widgets", JSON.stringify(widgets));
    },
        [widgets]
    )

    console.log("Connected : " + isLoggedIn);

    return (
        <div>
            <BrowserRouter>
                <MenuAppBar isLoggedIn={isLoggedIn} setIsLoggedIn={setIsLoggedIn} widgets={widgets} setWidgets={setWidgets} />

                {isLoggedIn ?
                    <Routes>
                        <Route path="/" element={<Home widgets={widgets} setWidgets={setWidgets} />}></Route>
                    </Routes>
                    :
                    <Routes>
                        <Route path="/signin" element={<SignIn setIsLoggedIn={setIsLoggedIn} isLoggedIn={isLoggedIn} />}>
                        </Route>

                        <Route path="/signup" element={<SignUp setIsLoggedIn={setIsLoggedIn} />}>
                        </Route>
                    </Routes>
                }
            </BrowserRouter>
        </div>

    )
}