import express from 'express';
import { pokemonController } from '../Controllers/pokemonController.js';

const router = express.Router();

// router.get('/', pokemonController);
router.post('/', pokemonController);

export default router;
