import styled from 'styled-components';

export const WeatherContainer = styled.section`
  height: 40vh;
  display: grid;
  grid-template-columns: 62% 1fr;
  width:65%;
`;

export const DataResult = styled.div`
  position: relative;
  object-fit: cover;
  
  .meta-data {
    position: absolute;
    top: 550px;
    left: 30px;
    h2 {
      color: #fff;
      font-size: 3rem;
    }

    .location-name {
      font-size: 1rem;
      color: inherit;
      font-weight: 500;
      margin-left: 0.4rem;
    }
  }
`;

export const InputContainer = styled.section`

  // ); /* Chrome 10-25, Safari 5.1-6 */
  // background: linear-gradient(
  //   to right,
  //   #7bc6cc,
  //   #be93c5
  // ); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
`;

export const SearchField = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 10px 20px 0 20px;
  .input {
    height: 50px;
    border: none;
    width: 100%;
    border-radius: 5px;
    margin-top:-7px;
    margin-bottom:-7px;
  }

  .input::-webkit-input-placeholder {
    padding-left: 6px;
  }

  .search-btn {
    margin-top: -8px;
    cursor: pointer;
    width: 100px;
    padding: 1.1rem;
    background-color: #1976d2;
    margin-left: 0.5rem;
    border-radius: 5px;
    border: none;
    color: #fff;
    font-weight: 600;
    letter-spacing: 0.1rem;
  }

  .close-btn{
    margin-top: -8px;
    cursor: pointer;
    width: 50px;
    padding: 1.1rem;
    background-color: #1976d2;
    margin-left: 0.5rem;
    border-radius: 5px;
    border: none;
    color: #fff;
    font-weight: 600;
    letter-spacing: 0.1rem;
  }
  button:hover{
    background-color: #1565c0;
  }
`;

export const ResultContainer = styled.div`
  h3 {
    color: black;
    margin: 5px 20px;
  }

  // bare minimuu styles
`;

export const Result = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  align-items: center;
  padding: 10px 30px 10px 10px;
  overflow: hidden;
  border-radius: 5px;
  box-shadow: 0 5px 7px -1px rgba(51, 51, 51, 0.23);
  cursor: pointer;
  margin: 5px 20px;

  background-color: #fff;

  .result__name {
    color: #979cb0;
    font-weight: 700;
    font-size: 18px;
    letter-spacing: 0.64px;
    margin-left: 12px;
  }

  .result__value {
    color: #35d8ac;
    font-weight: 900;
    font-size: 18px;
    text-align: right;

    & > span {
      opacity: 0.8;
      font-weight: 600;
      font-size: 12px;
      margin-left: 3px;
    }
  }
`;