import BlaguesAPI from 'blagues-api';

export const randomController = async (req, res) => {
    try {

        const blagues = new BlaguesAPI("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiMjQ2MDQ5OTMwODIzNTk4MDg1IiwibGltaXQiOjEwMCwia2V5IjoiZm43bWtrZ1g2VEZ6aTJSa2JITDVQNG1SMkhXOWdaeFdwMkQ1OVg2b0JmMlRxZUpJZmkiLCJjcmVhdGVkX2F0IjoiMjAyMi0wNS0wNFQwOTo0MDowMiswMDowMCIsImlhdCI6MTY1MTY1NzIwMn0.YnKZDMARr6kXu9GyAyRf4QJUi5aCmbQgETcFUkxWn5Y");
        const blague = await blagues.random();
        console.log(blague);
        res.status(200).json({
            blague,
        });
    } catch (error) {
        console.log(error);
        res.send(error);
    }
};