import React, { useState } from "react";
import "./AppPok.css";
import axios from "axios";
import Draggable from 'react-draggable';

export default function Pokemon({ widgets, setWidgets, id }) {

  const index = widgets.findIndex((w) => w.id === id);
  const widget = widgets[index];
  const deepCopy = JSON.parse(JSON.stringify(widgets));

  const [pokemon, setPokemon] = useState(widget.pokemon ?? '');
  const [pokemonData, setPokemonData] = useState([]);
  const [pokemonType, setPokemonType] = useState("");

  console.log("test", widget.pokemon);

  const handleChange = (e) => {
    setPokemon(e.target.value.toLowerCase());
    widget.pokemon = e.target.value.toLowerCase();
    deepCopy[index] = widget;
    setWidgets(deepCopy);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    getPokemon();
  };

  const getPokemon = async () => {
    const toArray = [];
    const config = {
      headers: {
        'Content-Type': 'application/json',
      },
    };

    const data = {
      pokemon: pokemon
    }

    try {
      const res = await axios.post(`http://localhost:5000/api/v2/pokemon`, data, config);
      toArray.push(res.data);
      console.log(res.data.data)
      setPokemonType(res.data.data.types[0].type.name);
      setPokemonData(toArray);
    } catch (error) {
      console.log(error);
    }

  }
  // console.log(pokemonData);

  const close = () => {
    const updatedWidgets = widgets.filter((w) => w.id !== id);
    console.log(updatedWidgets);
    setWidgets(updatedWidgets);
  }

  return (
    <Draggable>
      <div className="App">
        <div class="Close5">
          POKEDEX
          <button class="Close1" onClick={close}>X
          </button>
        </div>
        <form onSubmit={handleSubmit}>
          <label>
            <input
              type="text"
              onChange={handleChange}
              value={pokemon}
              placeholder="enter pokemon name"
            />
          </label>
        </form>
        {/* <ul>{pokemonData}</ul> */}
        {/* <p>{[pokemonData]}</p> */}
        {pokemonData.map((data) => {
          // console.log("DATA => ", data.data.sprites.front_default)
          return (
            <div className="container">
              <img src={data.data.sprites["front_default"]} />
              <div className="divTable">
                <div className="divTableBody">
                  <div className="divTableRow">
                    <div className="divTableCell">Type</div>
                    <div className="divTableCell">{pokemonType}</div>
                  </div>
                  <div className="divTableRow">
                    <div className="divTableCell">Height</div>
                    <div className="divTableCell">
                      {" "}
                      {Math.round(data.data.height * 3.9)}"
                    </div>
                  </div>
                  <div className="divTableRow">
                    <div className="divTableCell">Weight</div>
                    <div className="divTableCell">
                      {" "}
                      {Math.round(data.data.weight / 4.3)} lbs
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </Draggable>
  );
};