import axios from 'axios';
import React, { useState } from 'react';
import ResultCard from './ResultCard';
import {
  WeatherContainer,
  InputContainer,
  SearchField,
  ResultContainer,
  Result,
} from './Weather.Style';
import Draggable from 'react-draggable';

function Weather({ widgets, setWidgets, id }) {

  const index = widgets.findIndex((w) => w.id === id);
  const widget = widgets[index];
  const deepCopy = JSON.parse(JSON.stringify(widgets));

  const [city, setCity] = useState(widget.city ?? '');
  const [responseData, setResponseData] = useState('');
  const [loading, setLoading] = useState(false);

  const handelSubmit = async () => {
    setLoading(true);

    const config = {
      headers: {
        'Content-Type': 'application/json',
      },
    };

    const {
      data: { data },
    } = await axios.post(`http://localhost:5000/api/weather`, { city }, config);

    setResponseData(data);
    setLoading(false);
  };

  const handleChangeCity = (event) => {
    setCity(event.target.value);
    widget.city = event.target.value;
    deepCopy[index] = widget;
    setWidgets(deepCopy);

  };

  const close = () => {
    const updatedWidgets = widgets.filter((w) => w.id != id);
    console.log(updatedWidgets);
    setWidgets(updatedWidgets);
  }

  console.log(city);

  return (
    <Draggable>
      <WeatherContainer>
        <InputContainer>
          <ResultContainer>
            <h3>Realtime Weather Tracker</h3>
            <SearchField>
              <input
                type='text'
                placeholder='Enter City Name'
                className='input'
                value={city}
                onChange={handleChangeCity}
              />
              <button className='search-btn' onClick={handelSubmit}>
                Search
              </button>
              <button class="close-btn" onClick={close}>X
              </button>
            </SearchField>

            <h3>Weather Details</h3>

            {loading ? (
              <Result class='result__profile'>
                <span class='result__name'>Loading </span>
              </Result>
            ) : (
              <>
                {responseData ? (
                  <>
                    <ResultCard label='City' data={responseData.name} />
                    {/* <ResultCard2
                    label='Current Temperature'
                    data={responseData.main.temp}
                    unit='C'
                  /> */}
                    {/* <ResultCard
                    label='Maximum Recorded'
                    data={responseData.main.temp_max}
                    unit='C'
                  />
                  <ResultCard
                    label='Minimum Recorded'
                    data={responseData.main.temp_min}
                    unit='C'
                  /> */}
                    <ResultCard
                      label='Wind Speed'
                      data={responseData.wind.speed}
                      unit='Km/h'
                    />
                  </>
                ) : (
                  <Result class='result__profile'>
                    <span class='result__name'>
                      Please Enter a Valid City Name{' '}
                    </span>
                  </Result>
                )}
              </>
            )}
          </ResultContainer>
        </InputContainer>
      </WeatherContainer>
    </Draggable>
  );
}

export default Weather;
