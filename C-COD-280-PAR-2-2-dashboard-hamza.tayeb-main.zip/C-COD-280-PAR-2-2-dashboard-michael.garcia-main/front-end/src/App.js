import './App.css';
import React, { useState } from 'react';
import Index from "./components/Index";


function App() {

  const initialState = () => {
    if (localStorage.getItem("token")) {
      return true;
    }
    return false;
  }

  const [isLoggedIn, setIsLoggedIn] = useState(initialState());

  return (

    <div>

      <Index isLoggedIn={isLoggedIn} setIsLoggedIn={setIsLoggedIn} />


    </div>
  );
};

export default App;